<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sistema de Stock — Pro</title>
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">

  <!-- External libs: jsPDF + html2canvas (CDN) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <!-- NEW: Chart.js para el gráfico del balance -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <style>
    :root{ --gold:#cfae6d; --gold-2:#e0c184; --bg:#060606; --panel:#0f1112; --text:#f6f6f6; --muted:rgba(255,255,255,0.06); --accent:#2ac0c9; --danger:#ff6b6b; }
    *{box-sizing:border-box}
    body{margin:0;font-family:'Poppins',system-ui,-apple-system,Segoe UI,Roboto; background:linear-gradient(180deg,#070707 0%,#0f0f0f 100%); color:var(--text);}

    /* Header */
    header{padding:18px 24px; background:linear-gradient(90deg, rgba(0,0,0,0.5), rgba(0,0,0,0.25)); position:sticky; top:0; z-index:40; backdrop-filter: blur(6px);}
    .header-inner{max-width:1200px;margin:0 auto;display:flex;align-items:center;gap:16px}
    .logo{width:92px;border-radius:10px;object-fit:contain}
    h1{margin:0;font-weight:800;font-size:1.1rem;background:linear-gradient(90deg,var(--gold),var(--gold-2)); -webkit-background-clip:text;color:transparent}
    p.sub{margin:0;opacity:.85;color:rgba(255,255,255,.8)}

    .container{max-width:1200px;margin:28px auto;padding:20px;border-radius:14px;background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); box-shadow:0 18px 50px rgba(0,0,0,0.6);}

    /* Tabs */
    .tabs{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
    .tabs button{background:transparent;border:1px solid rgba(255,255,255,.04);padding:10px 14px;border-radius:999px;cursor:pointer;font-weight:600;transition:all .18s}
    .tabs button.active{background:linear-gradient(90deg, rgba(207,174,109,0.12), rgba(224,193,132,0.06));border:1px solid rgba(207,174,109,0.55);color:var(--gold-2)}

    /* Sections with smooth transitions */
    .seccion{opacity:0;transform:translateY(12px) scale(.995);max-height:0;overflow:hidden;transition:all .36s}
    .seccion.activa{opacity:1;transform:none;max-height:2600px}

    /* Form styles */
    form.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
    input,select,button{padding:12px;border-radius:10px;border:1px solid rgba(255,255,255,.04);background:rgba(255,255,255,0.02);color:var(--text);font-family:inherit}
    input:focus,select:focus{outline:none;box-shadow:0 10px 30px rgba(207,174,109,0.07);border-color:rgba(207,174,109,.4);transform:translateY(-2px)}
    button.primary{background:linear-gradient(90deg,var(--gold),var(--gold-2));color:#0b0b0b;font-weight:800;border:none}

    /* Table */
    .table-wrap{overflow:auto;border-radius:10px;border:1px solid rgba(255,255,255,0.03);margin-top:8px}
    table{width:100%;border-collapse:collapse;min-width:760px}
    th,td{padding:12px 14px;text-align:left;border-bottom:1px solid rgba(255,255,255,0.02)}
    thead th{position:sticky;top:0;background:linear-gradient(90deg, rgba(207,174,109,0.95), rgba(224,193,132,0.95));color:#070707;font-weight:800}
    tbody tr{transition:transform .15s, box-shadow .15s}
    tbody tr:hover{transform:translateY(-4px);box-shadow:0 12px 30px rgba(0,0,0,0.65)}

    /* Small helper */
    .muted{color:rgba(255,255,255,.55);font-size:.95rem}

    /* Modal */
    .modal-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:80;opacity:0;pointer-events:none;transition:opacity .2s}
    .modal-backdrop.show{opacity:1;pointer-events:auto}
    .modal{background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:18px;border-radius:12px;min-width:320px;box-shadow:0 18px 48px rgba(0,0,0,.7);border:1px solid rgba(255,255,255,.03)}

    /* Toast */
    .toast-container{position:fixed;right:18px;bottom:18px;z-index:100;display:flex;flex-direction:column;gap:8px}
    .toast{padding:12px 14px;border-radius:10px;background:rgba(20,20,20,.95);box-shadow:0 10px 30px rgba(0,0,0,.6);color:var(--text);font-weight:600}
    .toast.success{border-left:4px solid #2ecc71}
    .toast.error{border-left:4px solid var(--danger)}

    /* Fancy input labels */
    .field{position:relative}
    .field label{display:block;font-size:.82rem;margin-bottom:6px;color:rgba(255,255,255,.75)}

    /* PDF preview area (hidden) */
    #pdfPreview{display:none;padding:18px;background:white;color:black;border-radius:8px}

    @media (max-width:800px){.header-inner{padding:0 12px}.logo{width:78px}}

    /* subtle appearing animation */
    @keyframes popIn{from{opacity:0;transform:translateY(8px) scale(.99)}to{opacity:1;transform:none}}
    .animate-pop{animation:popIn .36s ease}

    /* NEW: tarjetas rápidas */
    .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin:10px 0 6px}
    .card{background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.04);border-radius:12px;padding:14px}
    .card h4{margin:0 0 4px;font-size:.9rem;color:var(--gold-2)}
    .card .big{font-size:1.4rem;font-weight:800}
  </style>
</head>
<body>
  <!-- LOGIN (demo) -->
  <div id="login" style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:28px;background:radial-gradient(circle at 10% 10%, rgba(207,174,109,0.04), transparent 5%), linear-gradient(135deg, rgba(0,0,0,0.9), rgba(12,12,12,0.95));">
    <form onsubmit="return iniciarSesion(event)" style="width:100%;max-width:420px;">
      <div style="background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:28px;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.6);border:1px solid rgba(255,255,255,.03)">
        <h2 style="margin:0 0 8px;color:var(--gold)">Bienvenido/a</h2>
        <p class="muted">Inicia sesión para administrar el stock</p>
        <div style="height:12px"></div>
        <input id="nombreEmpleadoInput" placeholder="Tu nombre" required style="width:100%;margin-bottom:10px" />
        <input id="usuario" placeholder="Usuario" required style="width:100%;margin-bottom:10px" />
        <input id="password" placeholder="Contraseña" type="password" required style="width:100%;margin-bottom:12px" />
        <div style="display:flex;gap:10px">
          <button type="submit" class="primary" style="flex:1">Entrar</button>
          <button type="button" onclick="autofillDemo()" style="flex:0">Demo</button>
        </div>
      </div>
    </form>
  </div>

  <!-- APP -->
  <div id="app" style="display:none">
    <header>
      <div class="header-inner">
        <img src="biro.jpg" alt="logo" class="logo"/>
        <div>
          <h1>🌸 Sistema de Control de Stock — Pro</h1>
          <p id="bienvenida" class="sub">&nbsp;</p>
        </div>
      </div>
    </header>

    <div class="container">
      <div class="tabs" role="tablist" aria-label="Pestañas principales">
        <button id="tab-agregar" onclick="mostrarSeccion('agregar')">➕ Agregar / Editar</button>
        <button id="tab-ver" onclick="mostrarSeccion('ver')">📦 Ver Stock</button>
        <button id="tab-pagos" onclick="mostrarSeccion('pagos')">💰 Pagos</button>
        <button id="tab-cierres" onclick="mostrarSeccion('cierres')">🧾 Cierres</button>
        <button onclick="cerrarSesion()">🔒 Cerrar Sesión</button>
      </div>

      <!-- Agregar -->
      <section id="seccion-agregar" class="seccion activa animate-pop">
        <h2 id="titulo-form">➕ Agregar Producto</h2>
        <form id="form-agregar" class="grid" data-mode="add">
          <input type="hidden" id="productoId" name="id" />
          <div class="field"><label>Nombre</label><input name="nombre" required /></div>
          <div class="field"><label>Cantidad</label><input name="cantidad" type="number" required /></div>
          <div class="field"><label>Precio</label><input name="descripcion" placeholder="Ej: 1200" /></div>
          <div class="field"><label>Código de barras</label><input name="codigo_barras" required /></div>
          <div class="field"><label>Foto</label><input type="file" name="foto" accept="image/*" /></div>
          <div style="grid-column:span 2;display:flex;gap:8px">
            <button id="btnForm" type="submit" class="primary">Agregar al stock</button>
            <button type="button" onclick="limpiarFormulario()">Limpiar</button>
          </div>
        </form>
      </section>

      <!-- Ver -->
      <section id="seccion-ver" class="seccion">
        <h2>📋 Ver Stock</h2>
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:8px">
          <div style="flex:1;max-width:420px"><input id="buscar" placeholder="Buscar por nombre o código..." style="width:100%" /></div>
          <div class="muted">Items: <span id="contador-productos">0</span></div>
        </div>
        <div class="table-wrap">
          <table aria-describedby="tabla-productos">
            <thead>
              <tr><th>ID</th><th>Nombre</th><th>Cód.</th><th>Cant.</th><th>Precio</th><th>Foto</th><th>Acción</th></tr>
            </thead>
            <tbody id="tabla-productos"></tbody>
          </table>
        </div>
      </section>

      <!-- Pagos -->
      <section id="seccion-pagos" class="seccion">
        <h2>💰 Registro de Pagos</h2>
        <form id="form-pagos" class="grid">
          <div class="field"><label>Cliente</label><input name="nombre_cliente" required /></div>
          <div class="field"><label>Concepto</label><input name="concepto" required /></div>
          <div class="field"><label>Monto</label><input name="monto" type="number" step="0.01" required /></div>
          <div class="field"><label>Fecha</label><input name="fecha" type="date" required /></div>
          <div class="field"><label>Método</label>
            <select name="metodo_pago" required>
              <option value="">Seleccionar</option>
              <option>Efectivo</option>
              <option>Transferencia</option>
              <option>Tarjeta</option>
            </select>
          </div>
          <div style="grid-column:span 2;display:flex;gap:8px">
            <button type="submit" class="primary">Registrar pago</button>
            <button type="button" onclick="abrirCerrarCajaModal()">🧾 Cerrar Caja</button>
          </div>
        </form>

        <!-- NEW: Resumen + gráfico del día -->
        <div class="cards">
          <div class="card">
            <h4>Ingresos del día</h4>
            <div class="big" id="ingresos-dia">$0.00</div>
          </div>
          <div class="card">
            <h4>Gastos del día</h4>
            <div class="big" id="gastos-dia">$0.00</div>
          </div>
          <div class="card">
            <h4>Neto</h4>
            <div class="big" id="neto-dia">$0.00</div>
          </div>
        </div>
        <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.04);padding:14px;border-radius:12px;margin:8px 0 14px">
          <label for="filtroFecha">Filtrar por fecha:</label>
          <input id="filtroFecha" type="date" />
          <div style="height:10px"></div>
          <canvas id="chartBalanceDia" height="110" aria-label="Gráfico de balance del día" role="img"></canvas>
        </div>

        <h3 style="margin-top:6px">📄 Pagos Registrados</h3>
        <div class="table-wrap" style="margin-top:8px">
          <table>
            <thead><tr><th>ID</th><th>Cliente</th><th>Concepto</th><th>Monto</th><th>Fecha</th><th>Hora</th><th>Acción</th></tr></thead>
            <tbody id="tabla-pagos"></tbody>
          </table>
        </div>

        <!-- NEW: Sección de Gastos -->
        <h2 style="margin-top:18px">📉 Registrar Gasto</h2>
        <form id="form-gastos" class="grid">
          <div class="field"><label>Proveedor / Concepto</label><input name="concepto" required /></div>
          <div class="field"><label>Monto</label><input name="monto" type="number" step="0.01" required /></div>
          <div class="field"><label>Fecha</label><input name="fecha" type="date" required /></div>
          <div style="grid-column:span 2;display:flex;gap:8px">
            <button type="submit" class="primary">Registrar gasto</button>
          </div>
        </form>

        <h3 style="margin-top:6px">🧾 Gastos Registrados</h3>
        <div class="table-wrap" style="margin-top:8px">
          <table>
            <thead><tr><th>ID</th><th>Concepto</th><th>Monto</th><th>Fecha</th><th>Hora</th><th>Acción</th></tr></thead>
            <tbody id="tabla-gastos"></tbody>
          </table>
        </div>
      </section>

      <!-- Cierres -->
      <section id="seccion-cierres" class="seccion">
        <h2>🧾 Historial de Cierres</h2>
        <div style="display:flex;gap:12px;align-items:center;margin-bottom:12px">
          <input id="filtroCierre" type="date" />
          <button onclick="exportarCierrePDF()" class="primary">Descargar Balance (PDF)</button>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>ID</th><th>Fecha</th><th>Hora</th><th>Total ($)</th></tr></thead>
            <tbody id="tabla-cierres"></tbody>
          </table>
        </div>

        <!-- Hidden printable preview used to build the PDF via html2canvas + jsPDF -->
        <div id="pdfPreview" aria-hidden="true"></div>
      </section>

    </div>
  </div>

  <!-- Modal for deleting payments / closing caja -->
  <div id="modal" class="modal-backdrop" role="dialog" aria-modal="true" style="display:none">
    <div class="modal" id="modalContent">
      <h3 id="modalTitle">Acción</h3>
      <p id="modalMessage" class="muted">&nbsp;</p>
      <div id="modalBody"></div>
      <div style="display:flex;gap:8px;margin-top:12px;justify-content:flex-end">
        <button onclick="cerrarModal()">Cancelar</button>
        <button id="modalConfirm" class="primary">Confirmar</button>
      </div>
    </div>
  </div>

  <!-- Toasts -->
  <div class="toast-container" id="toasts"></div>

  <script>
    // ------------------------
    // Demo users
    // ------------------------
    const usuariosValidos = [{ usuario: 'admin', password: 'admin' }];
    let nombreEmpleado = '';

    function autofillDemo(){ document.getElementById('usuario').value='admin'; document.getElementById('password').value='admin'; document.getElementById('nombreEmpleadoInput').value='Empleado Demo'; }

    function iniciarSesion(e){ e.preventDefault(); const usuario=document.getElementById('usuario').value.trim(); const password=document.getElementById('password').value.trim(); const nombre=document.getElementById('nombreEmpleadoInput').value.trim(); const valido = usuariosValidos.find(u=>u.usuario===usuario&&u.password===password); if(!valido){ mostrarToast('Usuario o contraseña incorrectos','error'); return false; } nombreEmpleado = nombre || usuario; document.getElementById('login').style.display='none'; document.getElementById('app').style.display='block'; document.getElementById('bienvenida').textContent = `Bienvenido/a, ${nombreEmpleado}`; // default tab
      document.querySelectorAll('.tabs button').forEach(b=>b.classList.remove('active')); document.getElementById('tab-ver').classList.add('active'); mostrarSeccion('ver'); cargarPagos(); cargarGastos(); cargarProductos(); cargarCierres(); actualizarBalanceYGrafico(); return false; }

    function cerrarSesion(){ if(confirm('Cerrar sesión?')){ nombreEmpleado=''; document.getElementById('app').style.display='none'; document.getElementById('login').style.display='flex'; }}

    function mostrarSeccion(nombre){ document.querySelectorAll('.seccion').forEach(s=>s.classList.remove('activa')); const el = document.getElementById('seccion-'+nombre); if(el) el.classList.add('activa'); document.querySelectorAll('.tabs button').forEach(b=>b.classList.remove('active')); const map={agregar:'tab-agregar', ver:'tab-ver', pagos:'tab-pagos', cierres:'tab-cierres'}; if(map[nombre]) document.getElementById(map[nombre]).classList.add('active'); if(nombre==='pagos'){ cargarPagos(); cargarGastos(); actualizarBalanceYGrafico(); } if(nombre==='ver') cargarProductos(); if(nombre==='cierres') cargarCierres(); }

    // ------------------------
    // Toasts
    // ------------------------
    function mostrarToast(msg, tipo='success', duration=3500){ const t=document.createElement('div'); t.className='toast '+(tipo==='error'?'error':'success'); t.textContent=msg; document.getElementById('toasts').appendChild(t); setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),400) }, duration); }

    // ------------------------
    // Modal
    // ------------------------
    function abrirModal({title='Confirmar', message='', bodyHtml='', confirmText='Confirmar', onConfirm=null}){
      const modal = document.getElementById('modal'); modal.style.display='flex'; setTimeout(()=>modal.classList.add('show'),10);
      document.getElementById('modalTitle').textContent = title; document.getElementById('modalMessage').textContent = message; document.getElementById('modalBody').innerHTML = bodyHtml; const btn = document.getElementById('modalConfirm'); btn.textContent = confirmText; btn.onclick = async ()=>{ if(onConfirm) await onConfirm(); cerrarModal(); } }
    function cerrarModal(){ const modal=document.getElementById('modal'); modal.classList.remove('show'); setTimeout(()=>modal.style.display='none',220); }

    // ------------------------
    // Forms behavior (AJAX)
    // ------------------------
    const formAgregar = document.getElementById('form-agregar'); const btnForm = document.getElementById('btnForm');
    formAgregar.addEventListener('submit', async e=>{ e.preventDefault(); const modo = formAgregar.dataset.mode; const datos = new FormData(formAgregar); if(modo==='add' && !formAgregar.foto?.value){ /* allow for demo */ }
      const url = modo==='add' ? 'add_stock.php' : 'update_stock.php'; try{ const resp = await fetch(url, { method:'POST', body:datos }); const info = await resp.json(); if(info.success){ mostrarToast(modo==='add' ? 'Producto agregado' : 'Producto actualizado'); formAgregar.reset(); formAgregar.dataset.mode='add'; document.getElementById('titulo-form').textContent='➕ Agregar Producto'; btnForm.textContent='Agregar al stock'; cargarProductos(); mostrarSeccion('ver'); } else { mostrarToast(info.error||'Error en operación','error'); } }catch(err){ console.error(err); mostrarToast('Ocurrió un error al comunicarse con el servidor','error'); } });

    function limpiarFormulario(){ formAgregar.reset(); formAgregar.dataset.mode='add'; document.getElementById('titulo-form').textContent='➕ Agregar Producto'; btnForm.textContent='Agregar al stock'; }

    // ------------------------
    // Productos
    // ------------------------
    async function cargarProductos(){ try{ const res = await fetch('fetch_stock.php'); if(!res.ok) throw new Error('Error server'); const datos = await res.json(); const tabla = document.getElementById('tabla-productos'); if(!Array.isArray(datos)) throw new Error('Formato inválido'); tabla.innerHTML = datos.map(p=>`
        <tr class="animate-pop">
          <td>${p.id}</td>
          <td>${p.nombre}</td>
          <td>${p.codigo_barras}</td>
          <td>${p.cantidad}</td>
          <td>${p.descripcion||''}</td>
          <td>${p.foto?`<img src="${p.foto}" alt="Foto" style="width:64px;border-radius:6px">`:''}</td>
          <td style="display:flex;gap:6px"><button class="editar" onclick="editarProducto(${p.id})">✏️</button></td>
        </tr>
      `).join(''); document.getElementById('contador-productos').textContent = datos.length; }catch(err){ console.error(err); document.getElementById('tabla-productos').innerHTML=`<tr><td colspan="7" style="text-align:center;color:rgba(255,255,255,.6)">No se pudieron cargar los productos.</td></tr>`; }
    }

    async function editarProducto(id){ try{ const res = await fetch(`fetch_stock.php?id=${id}`); if(!res.ok) throw new Error('No se pudo obtener el producto'); const prod = await res.json(); if(!prod.id) throw new Error('Producto no encontrado'); formAgregar.dataset.mode='edit'; document.getElementById('productoId').value = prod.id; formAgregar.nombre.value = prod.nombre; formAgregar.cantidad.value = prod.cantidad; formAgregar.descripcion.value = prod.descripcion; formAgregar.codigo_barras.value = prod.codigo_barras; btnForm.textContent='Actualizar'; document.getElementById('titulo-form').textContent='✏️ Editar Producto'; mostrarSeccion('agregar'); }catch(err){ mostrarToast(err.message,'error'); } }

    // ------------------------
    // Buscador (cliente-side)
    // ------------------------
    document.getElementById('buscar').addEventListener('input', function(){ const filtro=this.value.toLowerCase(); const filas=document.querySelectorAll('#tabla-productos tr'); filas.forEach(fila=>{ const nombre=fila.children[1]?.textContent.toLowerCase()||''; const codigo=fila.children[2]?.textContent.toLowerCase()||''; fila.style.display=(nombre.includes(filtro)||codigo.includes(filtro))? '':'none'; }); });

    // ------------------------
    // Pagos & eliminación con modal + password
    // ------------------------
    const formPagos = document.getElementById('form-pagos'); formPagos.addEventListener('submit', async e=>{ e.preventDefault(); const datos = new FormData(formPagos); try{ const resp = await fetch('add_pago.php', { method:'POST', body:datos }); const info = await resp.json(); if(info.success!==false){ mostrarToast('Pago registrado'); formPagos.reset(); cargarPagos(); actualizarBalanceYGrafico(); } else { mostrarToast(info.error||'Error al registrar pago','error'); } }catch(err){ console.error(err); mostrarToast('Error al registrar pago','error'); } });

    document.getElementById('filtroFecha').addEventListener('change', ()=>{ cargarPagos(); cargarGastos(); actualizarBalanceYGrafico(); });

    async function cargarPagos(){ const fecha = document.getElementById('filtroFecha').value || ''; let url = 'fetch_pagos.php'; if(fecha) url += `?fecha=${fecha}`; try{ const res = await fetch(url); if(!res.ok) throw new Error('Error en respuesta'); const pagos = await res.json(); const tbody = document.getElementById('tabla-pagos'); if(!Array.isArray(pagos) || pagos.length===0){ tbody.innerHTML = `<tr><td colspan="7" style="text-align:center">No hay pagos para esta fecha.</td></tr>`; setCachedPagos([]); return; } tbody.innerHTML = pagos.map(p=>`
        <tr>
          <td>${p.id}</td>
          <td>${p.nombre_cliente}</td>
          <td>${p.concepto}</td>
          <td>$${parseFloat(p.monto).toFixed(2)}</td>
          <td>${p.fecha}</td>
          <td>${p.hora}</td>
          <td style="display:flex;gap:6px"><button class="eliminar" onclick="confirmarEliminarPago(${p.id}, '${p.monto}')">🗑️</button></td>
        </tr>
      `).join(''); setCachedPagos(pagos); }catch(err){ console.error(err); document.getElementById('tabla-pagos').innerHTML = `<tr><td colspan="7" style="text-align:center;color:red">Error cargando pagos.</td></tr>`; setCachedPagos([]); } }

    function confirmarEliminarPago(id, monto){ abrirModal({ title:'Eliminar pago', message:`Vas a eliminar un pago por $${parseFloat(monto).toFixed(2)}. Ingresá la contraseña para confirmar.`, bodyHtml:`<input id="pwdEliminar" type="password" placeholder="Contraseña" style="width:100%;padding:10px;border-radius:8px;border:1px solid rgba(0,0,0,.08)" />`, confirmText:'Eliminar', onConfirm: async ()=>{ const pwd = document.getElementById('pwdEliminar').value; if(!pwd){ mostrarToast('Se requiere contraseña','error'); return; } try{ const res = await fetch('delete_pago.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`id=${id}&password=${encodeURIComponent(pwd)}` }); const data = await res.json(); if(data.success){ mostrarToast('Pago eliminado'); cargarPagos(); actualizarBalanceYGrafico(); } else { mostrarToast(data.error||'No se pudo eliminar el pago','error'); } }catch(err){ console.error(err); mostrarToast('Error al eliminar pago','error'); } } }); }

    // ------------------------
    // GASTOS (nuevo)
    // ------------------------
    const formGastos = document.getElementById('form-gastos');
    formGastos.addEventListener('submit', async (e)=>{ e.preventDefault(); const datos = new FormData(formGastos); try{ const resp = await fetch('add_gasto.php', { method:'POST', body:datos }); const info = await resp.json(); if(info.success!==false){ mostrarToast('Gasto registrado'); formGastos.reset(); cargarGastos(); actualizarBalanceYGrafico(); } else { mostrarToast(info.error||'Error al registrar gasto','error'); } }catch(err){ console.error(err); mostrarToast('Error al registrar gasto','error'); } });

    async function cargarGastos(){ const fecha = document.getElementById('filtroFecha').value || ''; let url = 'fetch_gastos.php'; if(fecha) url += `?fecha=${fecha}`; try{ const res = await fetch(url); if(!res.ok) throw new Error('Error en respuesta'); const gastos = await res.json(); const tbody = document.getElementById('tabla-gastos'); if(!Array.isArray(gastos) || gastos.length===0){ tbody.innerHTML = `<tr><td colspan="6" style="text-align:center">No hay gastos para esta fecha.</td></tr>`; setCachedGastos([]); return; } tbody.innerHTML = gastos.map(g=>`
        <tr>
          <td>${g.id}</td>
          <td>${g.concepto}</td>
          <td>$${parseFloat(g.monto).toFixed(2)}</td>
          <td>${g.fecha}</td>
          <td>${g.hora}</td>
          <td style="display:flex;gap:6px"><button class="eliminar" onclick="confirmarEliminarGasto(${g.id}, '${g.monto}')">🗑️</button></td>
        </tr>
      `).join(''); setCachedGastos(gastos); }catch(err){ console.error(err); document.getElementById('tabla-gastos').innerHTML = `<tr><td colspan="6" style="text-align:center;color:red">Error cargando gastos.</td></tr>`; setCachedGastos([]); } }

    function confirmarEliminarGasto(id, monto){ abrirModal({ title:'Eliminar gasto', message:`Vas a eliminar un gasto por $${parseFloat(monto).toFixed(2)}. Ingresá la contraseña para confirmar.`, bodyHtml:`<input id=\"pwdEliminar\" type=\"password\" placeholder=\"Contraseña\" style=\"width:100%;padding:10px;border-radius:8px;border:1px solid rgba(0,0,0,.08)\" />`, confirmText:'Eliminar', onConfirm: async ()=>{ const pwd = document.getElementById('pwdEliminar').value; if(!pwd){ mostrarToast('Se requiere contraseña','error'); return; } try{ const res = await fetch('delete_gasto.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`id=${id}&password=${encodeURIComponent(pwd)}` }); const data = await res.json(); if(data.success){ mostrarToast('Gasto eliminado'); cargarGastos(); actualizarBalanceYGrafico(); } else { mostrarToast(data.error||'No se pudo eliminar el gasto','error'); } }catch(err){ console.error(err); mostrarToast('Error al eliminar gasto','error'); } } }); }

    // ------------------------
    // Grafico de Balance (Chart.js)
    // ------------------------
    let chartBalance = null;
    let _cachePagos = []; let _cacheGastos = [];
    function setCachedPagos(p){ _cachePagos = Array.isArray(p)?p:[]; }
    function setCachedGastos(g){ _cacheGastos = Array.isArray(g)?g:[]; }

    function sumatoria(arr){ return arr.reduce((acc,x)=> acc + (parseFloat(x.monto)||0), 0); }

    function actualizarBalanceYGrafico(){
      const ingresos = sumatoria(_cachePagos);
      const gastos   = sumatoria(_cacheGastos);
      const neto     = ingresos - gastos;
      document.getElementById('ingresos-dia').textContent = `$${ingresos.toFixed(2)}`;
      document.getElementById('gastos-dia').textContent   = `$${gastos.toFixed(2)}`;
      document.getElementById('neto-dia').textContent     = `$${neto.toFixed(2)}`;

      const ctx = document.getElementById('chartBalanceDia').getContext('2d');
      const data = { labels:['Ingresos','Gastos','Neto'], datasets:[{ label:'$ del día', data:[ingresos, gastos, neto] }] };
      const options = { responsive:true, plugins:{ legend:{ display:false }, tooltip:{ callbacks:{ label:(ctx)=> `$ ${ctx.parsed.y?.toFixed(2)}` } } }, scales:{ y:{ beginAtZero:true } } };
      if(chartBalance){ chartBalance.data = data; chartBalance.options = options; chartBalance.update(); }
      else { chartBalance = new Chart(ctx, { type:'bar', data, options }); }
    }

    // ------------------------
    // Cierres y export PDF
    // ------------------------
    async function cargarCierres(){ try{ const res = await fetch('fetch_cierres.php'); if(!res.ok) throw new Error('Error server'); const cierres = await res.json(); const tbody = document.getElementById('tabla-cierres'); if(!Array.isArray(cierres) || cierres.length===0){ tbody.innerHTML = `<tr><td colspan="4" style="text-align:center">No hay cierres.</td></tr>`; return; } tbody.innerHTML = cierres.map(c=>`<tr><td>${c.id}</td><td>${c.fecha}</td><td>${c.hora}</td><td>$${parseFloat(c.total).toFixed(2)}</td></tr>`).join(''); }catch(err){ console.error(err); document.getElementById('tabla-cierres').innerHTML = `<tr><td colspan="4" style="text-align:center;color:red">Error cargando cierres.</td></tr>`; } }

    function abrirCerrarCajaModal(){ abrirModal({ title:'Cerrar caja', message:'¿Deseás cerrar la caja ahora? Esta acción generará un cierre con el total del día.', bodyHtml:`<div class="muted">Usuario: ${nombreEmpleado}</div>`, confirmText:'Cerrar caja', onConfirm: async ()=>{ try{ const res = await fetch('cerrar_caja.php', { method:'POST' }); const data = await res.json(); if(data.success){ mostrarToast(`Caja cerrada por $${parseFloat(data.total).toFixed(2)}`); cargarCierres(); } else { mostrarToast(data.error||'Error al cerrar caja','error'); } }catch(err){ console.error(err); mostrarToast('Error al cerrar caja','error'); } } }); }

    // Export selected closure (by date) to PDF using html2canvas + jsPDF
    async function exportarCierrePDF(){ const fecha = document.getElementById('filtroCierre').value; if(!fecha){ mostrarToast('Seleccioná una fecha para exportar','error'); return; }
      try{
        const res = await fetch(`fetch_cierres.php?fecha=${fecha}`);
        if(!res.ok) throw new Error('Error al solicitar cierre');
        const cierres = await res.json();
        if(!Array.isArray(cierres) || cierres.length===0){ mostrarToast('No se encontró cierre para esa fecha','error'); return; }

        const cierre = cierres[0];
        const pagosRes = await fetch(`fetch_pagos.php?fecha=${fecha}`);
        const pagos = await pagosRes.json();
        const gastosRes = await fetch(`fetch_gastos.php?fecha=${fecha}`);
        const gastos = await gastosRes.json();

        const preview = document.getElementById('pdfPreview');
        preview.style.display='block';
        preview.innerHTML = `
          <div style="padding:18px;font-family:Arial;line-height:1.4">
            <h2 style="margin:0 0 6px">Balance de Cierre — ${cierre.fecha}</h2>
            <div style="margin-bottom:10px;">Generado por: ${nombreEmpleado} — Hora: ${cierre.hora}</div>
            <h3>Ingresos</h3>
            <table style="width:100%;border-collapse:collapse;margin-bottom:8px">
              <thead>
                <tr style="background:#f2f2f2;color:#000"><th style="padding:8px;border:1px solid #ddd">ID</th><th style="padding:8px;border:1px solid #ddd">Cliente</th><th style="padding:8px;border:1px solid #ddd">Concepto</th><th style="padding:8px;border:1px solid #ddd">Monto</th></tr>
              </thead>
              <tbody>
                ${Array.isArray(pagos) ? pagos.map(p=>`<tr><td style="padding:8px;border:1px solid #ddd">${p.id}</td><td style="padding:8px;border:1px solid #ddd">${p.nombre_cliente}</td><td style="padding:8px;border:1px solid #ddd">${p.concepto}</td><td style="padding:8px;border:1px solid #ddd">$${parseFloat(p.monto).toFixed(2)}</td></tr>`).join('') : ''}
              </tbody>
            </table>
            <h3>Gastos</h3>
            <table style="width:100%;border-collapse:collapse">
              <thead>
                <tr style="background:#f2f2f2;color:#000"><th style="padding:8px;border:1px solid #ddd">ID</th><th style="padding:8px;border:1px solid #ddd">Concepto</th><th style="padding:8px;border:1px solid #ddd">Monto</th></tr>
              </thead>
              <tbody>
                ${Array.isArray(gastos) ? gastos.map(g=>`<tr><td style=\"padding:8px;border:1px solid #ddd\">${g.id}</td><td style=\"padding:8px;border:1px solid #ddd\">${g.concepto}</td><td style=\"padding:8px;border:1px solid #ddd\">$${parseFloat(g.monto).toFixed(2)}</td></tr>`).join('') : ''}
              </tbody>
            </table>
            <h3 style="margin-top:12px">Total ingresos: $${sumatoria(pagos||[]).toFixed(2)} — Total gastos: $${sumatoria(gastos||[]).toFixed(2)} — Neto: $${(sumatoria(pagos||[])-sumatoria(gastos||[])).toFixed(2)}</h3>
          </div>
        `;

        await new Promise(r=>setTimeout(r,120));
        const canvas = await html2canvas(preview, { scale:2 });
        const imgData = canvas.toDataURL('image/png');
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p','mm','a4');
        const pageWidth = pdf.internal.pageSize.getWidth();
        const imgProps = pdf.getImageProperties(imgData);
        const pdfHeight = (imgProps.height * pageWidth) / imgProps.width;
        pdf.addImage(imgData, 'PNG', 8, 8, pageWidth-16, pdfHeight);
        pdf.save(`balance_cierre_${fecha}.pdf`);

        preview.style.display='none';
      }catch(err){ console.error(err); mostrarToast('Error al generar PDF','error'); }
    }

    // ------------------------
    // Init defaults
    // ------------------------
    document.addEventListener('DOMContentLoaded', ()=>{
      const hoy = new Date().toISOString().split('T')[0];
      document.getElementById('filtroFecha').value = hoy; document.getElementById('filtroCierre').value = hoy;
      document.addEventListener('keydown', e=>{ if(e.key==='Escape') cerrarModal(); });
    });
  </script>
  <script>
  function cargarTotales() {
    fetch('fetch_totales.php')
        .then(res => res.json())
        .then(data => {
            document.getElementById('ingresos-dia').innerText = `$${data.ingresos.toFixed(2)}`;
            document.getElementById('gastos-dia').innerText = `$${data.gastos.toFixed(2)}`;
            document.getElementById('neto-dia').innerText    = `$${data.neto.toFixed(2)}`;
        })
        .catch(err => console.error('Error al cargar totales:', err));
}

// Llamar al cargar la página y cada vez que registres pago o gasto
cargarTotales();



// Registrar ingreso
document.getElementById("form-pago").addEventListener("submit", function(e) {
    e.preventDefault();
    fetch("add_pago.php", {
        method: "POST",
        body: new FormData(this)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            this.reset();
            cargarTotales();
        } else {
            alert("Error al registrar ingreso: " + data.error);
        }
    });
});

// Registrar gasto
document.getElementById("form-gasto").addEventListener("submit", function(e) {
    e.preventDefault();
    fetch("add_gasto.php", {  // <-- aquí estaba el error, antes llamaba a add_pago.php
        method: "POST",
        body: new FormData(this)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            this.reset();
            cargarTotales();
        } else {
            alert("Error al registrar gasto: " + data.error);
        }
    });
});





   </script>



</body>
</html>